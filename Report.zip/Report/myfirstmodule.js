exports.myDateTime = function () {
    return Date();
};
/**
 * http://usejsdoc.org/
 */
