exports.SQLConn = function()
{
	var mysql = require('mysql');
	var con = mysql.createConnection({
		  host: "localhost",
		  user: "root",
		  password: "admin1",
		  database: "Report"
		});
	var users='';
/*	con.connect(function(err) {
		  if (err) throw err;
		  con.query("SELECT * FROM user", function (err, result, fields) {
		    if (err) throw err;
		    users = users + result +'\n';
		  });
		});
	console.log('Server users='+users); */
	return con;
};
exports.getData = function(con,res)
{
	var users='';
	con.connect(function(err) {
		  if (err) throw err;
		  con.query("SELECT * FROM user", function (err, result, fields) {
		    if (err) throw err;
		    const queryResult = result;
		    console.log('queryResult='+queryResult);
		    res.end('\nqueryResult='+JSON.stringify(queryResult, null));
		  });
		});
};
/**
 * http://usejsdoc.org/
 */
