var dt = require('./myfirstmodule');
var url = require('url');
var sqldb = require('./sqlconnection');
var express = require('express');
var path = require("path");
var app = express();
app.get('/', function(req, res){
    const query = url.parse(req.url,false);
    console.log('query='+query.pathname);
    const con = sqldb.SQLConn();
    res.sendFile(path.join(__dirname+'/Login.html'));
   // res.end('this code executes.');
    //sqldb.getData(con,res);
});
app.get('/login', function(req, res){
	console.log(req.param('password'));
    console.log(req.param('username'));
    res.redirect('/welcome');
});
app.get('/welcome', function(req, res){
	res.sendFile(path.join(__dirname+'/Welcome.html'));
});
app.listen(1337);

console.log('Server running at http://127.0.0.1:1337/');
